public interface CommunicationChannel {
    void send(String receiver, String message);
}
